(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    // Initiate the wowjs
    new WOW().init();

    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.nav-bar').addClass('sticky-top');
        } else {
            $('.nav-bar').removeClass('sticky-top');
        }
    });
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });

    // Header carousel
    $(".header-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1500,
        items: 1,
        dots: true,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ]
    });

    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        margin: 24,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0: {
                items: 1
            },
            992: {
                items: 2
            }
        }
    });

})(jQuery);

// Your IoT connection settings
const secretId = 'ThbZZbuDrAvpEvqvpvuFnfbCq'; // Replace with your actual secret
const socket = io.connect(`http://your-server-url?secret=${secretId}`); // Replace with your server URL

// Ensure DOM is loaded before adding event listeners
document.addEventListener('DOMContentLoaded', function () {
    // Toggle LED on button click
    const toggleButton = document.getElementById('toggleLED');
    if (toggleButton) {
        toggleButton.addEventListener('click', function () {
            socket.emit('toggleLED'); // Send toggle command to Arduino
        });
    }

    // Update Fan speed based on slider input
    const fanSlider = document.getElementById('fanSpeed');
    if (fanSlider) {
        fanSlider.addEventListener('input', function () {
            const fanSpeed = this.value;
            const fanSpeedValue = document.getElementById('fanSpeedValue');
            if (fanSpeedValue) {
                fanSpeedValue.textContent = fanSpeed;
            }
            socket.emit('setFanSpeed', fanSpeed); // Send fan speed to Arduino
        });
    }

    // Listen for sensor data updates from Arduino
    socket.on('irStatus', function (status) {
        const irStatus = document.getElementById('irStatus');
        if (irStatus) {
            irStatus.textContent = status ? 'Active' : 'Inactive';
        }
    });

    socket.on('photoresistorStatus', function (status) {
        const photoresistorStatus = document.getElementById('photoresistorStatus');
        if (photoresistorStatus) {
            photoresistorStatus.textContent = status ? 'Active' : 'Inactive';
        }
    });

    socket.on('ledStatus', function (status) {
        const ledStatus = document.getElementById('ledStatus');
        if (ledStatus) {
            ledStatus.textContent = status ? 'On' : 'Off';
        }
    });
});
